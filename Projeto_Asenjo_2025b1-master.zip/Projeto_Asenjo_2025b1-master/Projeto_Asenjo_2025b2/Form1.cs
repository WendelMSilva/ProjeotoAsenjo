﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using Projeto_Asenjo_2025b2.classes;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Projeto_Asenjo_2025b2
{
    public partial class FormCadastro : Form
    {
        Pessoa umapessoa = new Pessoa();
        public FormCadastro()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {
        }
        private void label9_Click(object sender, EventArgs e)
        {
        }
        private void label12_Click(object sender, EventArgs e)
        {
        }
        private void label13_Click(object sender, EventArgs e)
        {
        }
         private void button4_Click(object sender, EventArgs e) //BOTÃO CONSULTA
         {
            //if(txID.Text != string.Empty)
            //{
            //    button1.Enabled = true;
            //    button2.Enabled = true;
            //}
            //else
            //{    
            //    MessageBox.Show("Por favor, insira um ID.");
            //}
           
            umapessoa.setId(txID.Text);
            PessoaBLL.validaId(umapessoa);
            if (Erro.getErro())
                MessageBox.Show(Erro.getMsg());
            else
            {
                txID.Text = umapessoa.getId().ToString();
                txNome.Text = umapessoa.getNome();
                txTelefone.Text = umapessoa.getTelefone();
                txEmail.Text = umapessoa.getEmail();
                txCEP.Text = umapessoa.getCep();
                txEstado.Text = umapessoa.getEstado();
                txCidade.Text = umapessoa.getCidade();
                txBairro.Text = umapessoa.getBairro(); 
                txRua.Text = umapessoa.getRua();
                txNumero.Text = umapessoa.getNumero();
                txComplemento.Text = umapessoa.getComplemento();
            }

        }

        private void button3_Click(object sender, EventArgs e)// BOTÃO CADASTRAR
        {
            //umapessoa.setId(txID.Text);
            umapessoa.setNome(txNome.Text);
            umapessoa.setEmail(txEmail.Text);
            umapessoa.setTelefone(txTelefone.Text);
            umapessoa.setCep(txCEP.Text);
            umapessoa.setEstado(txEstado.Text);
            umapessoa.setCidade(txCidade.Text);
            umapessoa.setBairro(txBairro.Text);
            umapessoa.setRua(txRua.Text);
            umapessoa.setNumero(txNumero.Text);
            umapessoa.setComplemento(txComplemento.Text);

            /* Pessoa.setNome(txNome.Text);
            Pessoa.setEmail(txEmail.Text);
            Pessoa.setTelefone(txTelefone.Text);
            Pessoa.setCep(txCEP.Text);
            Pessoa.setEstado(txEstado.Text);
            Pessoa.setCidade(txCidade.Text);
            Pessoa.setBairro(txBairro.Text);
            Pessoa.setRua(txRua.Text);
            Pessoa.setNumero(txNumero.Text);
            Pessoa.setComplemento(txComplemento.Text);*/
            PessoaBLL.validaDados();
            if (Erro.getErro())
            {
                MessageBox.Show(Erro.getMsg());
            }
            else
            {

                MessageBox.Show($"Cadastro realizado com sucesso!");
            }
        }

        private void button1_Click(object sender, EventArgs e)//BOTÃO SALVAR
        {

        }

        private void FormCadastro_Load(object sender, EventArgs e)
        {
            PessoaBLL.conecta();
            if (Erro.getErro())
                MessageBox.Show(Erro.getMsg());
            button1.Enabled = false;
            button2.Enabled = false;
            //if (Erro.getErro())
            //    MessageBox.Show(Erro.getMsg());
        }

        private void button2_Click(object sender, EventArgs e) // BOTÃO EXCLUIR
        {
            txNome.Text = txEmail.Text = txTelefone.Text = txCEP.Text = txEstado.Text =
            txCidade.Text = txBairro.Text = txRua.Text = txNumero.Text = txComplemento.Text = "";
            MessageBox.Show("Usuário excluido com sucesso com sucesso!");
        }

        private async void txCEP_Leave(object sender, EventArgs e)
        {
            string cep = txCEP.Text.Replace("-", "").Trim();
            if (cep.Length != 8)
            {
                MessageBox.Show("Digite um CEP válido com 8 dígitos!");
                return;
            }

            await PessoaBLL.PreencherPessoaPorCep(cep);

            if (Erro.getErro())
            {
                MessageBox.Show(Erro.getMsg());
                return;
            }

            // Atualiza os TextBox
            txEstado.Text = umapessoa.getEstado();
            txCidade.Text = umapessoa.getCidade();
            txBairro.Text = umapessoa.getBairro();
            txRua.Text = umapessoa.getRua();
            txComplemento.Text = umapessoa.getComplemento();
        }



        private void txEstado_TextChanged(object sender, EventArgs e)
        {
        }

        private void txNome_TextChanged(object sender, EventArgs e)
        {

        }

        private void CadFormCadastro_FormClosing(object sender, FormClosingEventArgs e)
        {
            PessoaBLL.desconectar();
        }
    }
}
