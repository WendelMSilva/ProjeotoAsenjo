﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projeto_Asenjo_2025b2.classes
{
    public class Pessoa
    {
        private static string nome;
        private static string email;
        private static string telefone;
        private static string cep;
        private static string estado;
        private static string cidade;
        private static string bairro;
        private static string rua;
        private static string numero;
        private static string complemento;
        private static string id;

        public void setNome(string _nome) { nome = _nome; }
        public void setEmail(string _email) { email = _email; }
        public void setTelefone(string _telefone) { telefone = _telefone; }
        public void setCep(string _cep) { cep = _cep; }
        public void setEstado(string _estado) { estado = _estado; }
        public void setCidade(string _cidade) { cidade = _cidade; }
        public void setBairro(string _bairro) { bairro = _bairro; }
        public void setRua(string _rua) { rua = _rua; }
        public void setNumero(string _numero) { numero = _numero; }
        public void setComplemento(string _complemento) { complemento = _complemento; }
        public void setId(string _id) { id = _id; }


        public string getNome() { return nome; }
        public string getEmail() { return email; }
        public string getTelefone() { return telefone; }
        public string getCep() { return cep; }
        public string getEstado() { return estado; }
        public string getCidade() { return cidade; }
        public string getBairro() { return bairro; }
        public string getRua() { return rua; }
        public string getNumero() { return numero; }
        public string getComplemento() { return complemento; }
        public string getId() { return id; }


    }
}
