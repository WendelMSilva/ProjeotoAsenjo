﻿using System;
using System.Collections.Generic;
using System.Data.OleDb;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Projeto_Asenjo_2025b2.classes
{
    internal class PessoaDAL
    {
        private static String strConexao = "Provider=Microsoft.Jet.OLEDB.12.0;Data Source=BDCadPessoa.accdb";
        private static OleDbConnection conn = new OleDbConnection(strConexao);
        private static OleDbCommand strSQL;
        private static OleDbDataReader result;

        public static void conecta()
        {
            try
            {
                conn.Open();
            }
            catch (Exception)
            {
                Erro.setMsg("Problemas ao se conectar ao Banco de Dados!");
            }
        }

        public static void desconectar()
        {
            conn.Close();
        }

        public static void inserirUmaPessoa(Pessoa umapessoa)
        {
            String aux = "insert into TabCadPessoa(id,nome,telefone,email,cep,estado,rua,cidade,bairro,numero,complemento) values (@id,@nome,@telefone,@email,@cep,@estado,@rua,@cidade,@bairro,@numero,@complemento)";
            strSQL = new OleDbCommand(aux, conn);

            //strSQL.Parameters.Add("@codigo", OleDbType.VarChar).Value = umapessoa.getCodigo();
            strSQL.Parameters.Add("@id", OleDbType.VarChar).Value = umapessoa.getId();
            strSQL.Parameters.Add("@nome", OleDbType.VarChar).Value = umapessoa.getNome();
            strSQL.Parameters.Add("@telefone", OleDbType.VarChar).Value = umapessoa.getTelefone();
            strSQL.Parameters.Add("@email", OleDbType.VarChar).Value = umapessoa.getEmail();
            strSQL.Parameters.Add("@cep", OleDbType.VarChar).Value = umapessoa.getCep();
            strSQL.Parameters.Add("@estado", OleDbType.VarChar).Value = umapessoa.getEstado();
            strSQL.Parameters.Add("@rua", OleDbType.VarChar).Value = umapessoa.getRua();
            strSQL.Parameters.Add("@cidade", OleDbType.VarChar).Value = umapessoa.getCidade();
            strSQL.Parameters.Add("@bairro", OleDbType.VarChar).Value = umapessoa.getBairro();
            strSQL.Parameters.Add("@numero", OleDbType.VarChar).Value = umapessoa.getNumero();
            strSQL.Parameters.Add("@complemento", OleDbType.VarChar).Value = umapessoa.getComplemento();
            strSQL.ExecuteNonQuery();
        }

        public static void consultaUmaPessoa(Pessoa umapessoa)
        {
            String aux = "select * from TabCadPessoa where id = @id";
            strSQL = new OleDbCommand(aux, conn);

            strSQL.Parameters.Add("@id", OleDbType.VarChar).Value = umapessoa.getId();

            result = strSQL.ExecuteReader();
            Erro.setErro(false);
            if (result.Read())
            {   
                umapessoa.setNome(result.GetString(1));
                umapessoa.setTelefone(result.GetString(2));
                umapessoa.setEmail(result.GetString(3));
                umapessoa.setCep(result.GetString(4));
                umapessoa.setEstado(result.GetString(5));
                umapessoa.setRua(result.GetString(6));
                umapessoa.setCidade(result.GetString(7));
                umapessoa.setBairro(result.GetString(8));
                umapessoa.setNumero(result.GetString(9));
                umapessoa.setComplemento(result.GetString(10));

            }
            else
                Erro.setMsg("Pessoa não cadastrada.");
        }
       

    }
}
