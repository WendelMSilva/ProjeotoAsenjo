# PENDENCIAS QUE DEIXEI.

-Conexão com o bando de dados

-Criação da classe DAL

-Quando adicionada uma pessoa incrementar um ID para cada uma(+=1)

-Dar funcionalidade para a TxID e o botão consultar

-Dar funcionalidade para os botões basicos, eu fiz todas as verificações ja, mas eles ainda n salvam/excluem nada

acho q é isso

# Coisas que talvez seja importante voce saber

O botão salvar e excluir só ficam funcionais caso a txID tenha um id valido e acione o botão de consultar, fiz isso pq não faz sentido voce salvar novos dados para um pessoa não cadastrada e nem excluir uma pessoa não cadastrada.

os TextBox sempre vão começar com as letras tx...

os botões eu vacilei e esqueci de colocar nome neles ent ta button1, 2, 3 ...

acho q é isso
